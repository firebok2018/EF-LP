-- borra la bd si existe
DROP DATABASE IF EXISTS ciberfarma;
-- creamos la bd
CREATE DATABASE ciberfarma;
-- activamos la bd
USE ciberfarma;


CREATE TABLE tb_usuarios(
codigo  int auto_increment,
nombre varchar(15),
apellido varchar(25),
usuario  char(4) NOT NULL,
clave    char(5),
facceso date  null,
tipo    int DEFAULT 2,
estado  int(1) DEFAULT 1,
primary key (codigo)
);

create table tb_categorias(
idtipo		int not null primary key,
descripcion varchar(45)
);

create table tb_productos(
idprod      char(5) not null,
descripcion varchar(45),
stock		int,
precio		decimal(8,2),
idtipo		int,
estado		boolean,
primary key (idprod), 
foreign key (idtipo) references tb_categorias(idtipo)
);

create table tb_ventas(
numvta      char(5) not null,
idprod      char(5) not null,
-- descripcion varchar(30),
cantidad    int,
preciovta   decimal(8,2),
fechavta    date,
codvendedor int not null,
primary key (numvta,idprod),
foreign key (idprod) references tb_productos(idprod),
foreign key (codvendedor) references tb_usuarios(codigo)
);

-- inserts

insert into tb_usuarios values (null,'Tito', 'Siber','U001', '10001', curdate(),2,1);
insert into tb_usuarios values (null,'Zoila', 'Baca','U002', '10002', curdate(),2,1);

insert into tb_categorias values (1, 'Pastillas');
insert into tb_categorias values (2, 'Jarabe');
insert into tb_categorias values (3, 'Otros');

insert into tb_productos values ('P0001','Panadol cj 10',20,1.5,1,1);
insert into tb_productos values ('P0002','Curitas unidad',100,1.0,3,1);
insert into tb_productos values ('P0003','Kita tos',80,15.0,2,1);
insert into tb_productos values ('P0004','Achiz',120,1.0,1,1);
insert into tb_productos values ('P0005','Jaboncillo cj',120,1.0,3,1);


insert into tb_ventas values ('V0001','P0001', 1, 1.50, '2017/04/15',1 );
insert into tb_ventas values ('V0001','P0004', 2, 1.0,  '2017/04/15',1 );
insert into tb_ventas values ('V0002','P0002', 1, 1.0,  '2017/04/25', 2);
insert into tb_ventas values ('V0003','P0003', 1, 15.0,  '2017/04/26',2 );
insert into tb_ventas values ('V0004','P0002', 1, 1.0,  '2017/05/01',1);
insert into tb_ventas values ('V0004','P0005', 1, 1.0,  '2017/05/01',1 );

-- consultas
SELECT * FROM tb_usuarios;
SELECT * FROM tb_ventas;
SELECT * FROM tb_productos;



-- ejemplo de procedimientos almancenados de consulta
DELIMiTER $$
create procedure usp_validaAcceso (usr char(4), pas char(5))
begin
select * from tb_usuarios where usuario = usr and clave = pas;
end$$
DELIMiTER ;

CALL usp_validaAcceso ('U001','10001');

DELIMiTER $$
create procedure usp_reporte1 ()
begin
SELECT numvta, fechavta, p.descripcion as 'Nombre del Producto', 
	concat(u.nombre, " ",u.apellido) as 'Nombre del vendedor', 
    (v.cantidad * v.preciovta) as 'Monto de la venta'
 FROM tb_ventas v
INNER JOIN tb_usuarios u ON v.codvendedor = u.codigo
INNER JOIN tb_productos p ON v.idprod = p.idprod;

end$$
DELIMiTER ;

CALL usp_reporte1 ();

