package interfaces;

import java.util.ArrayList;

import model.Usuario;

public interface UsuarioInterface {

	// los m�todos de mantenimiento
	
	// -- registrar los datos del usuario
	public int registrar(Usuario u);
	
	// m�todo para lista el contenido de las tablas
	public ArrayList<Usuario> listado();
	

	
}
