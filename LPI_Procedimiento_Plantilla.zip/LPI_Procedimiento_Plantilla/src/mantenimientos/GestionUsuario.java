package mantenimientos;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import interfaces.UsuarioInterface;
import model.Usuario;
import utils.MySQLConexion;

public class GestionUsuario implements UsuarioInterface {

	@Override
	public int registrar(Usuario u) {
		// conexion con la BD, las sentencias, etc
		int rs = 0; // tipo de resultado
		Connection con = null;
		PreparedStatement pst = null;
		try {
		   con = MySQLConexion.getConexion(); 
		   String sql = "insert into tb_usuarios values (null,?, ?, ?, ?, ?, curdate(),default,default)"; 		  

		   pst = con.prepareStatement(sql);
		   // par�metros seg�n la sentencia
		   pst.setString(1, u.getNombre());
		   pst.setString(2, u.getApellido());
		   pst.setString(3, u.getUsuario());
		   pst.setString(4, u.getClave());
		   pst.setString(5, u.getFacceso());
		   
		   rs = pst.executeUpdate(); // tipo de ejecuci�n

		   // Acciones adicionales en caso de consultas
		} catch (Exception e) {
		   System.out.println("Error en la sentencia " + e.getMessage());
		} finally {
		  try {
		      if (pst != null) pst.close();
		      if (con != null) con.close();
		   } catch (SQLException e) {
		      System.out.println("Error al cerrar ");
		   }
		}

		return rs; 
	}

	@Override
	public ArrayList<Usuario> listado() {
		ArrayList<Usuario> lista = new ArrayList<Usuario>();
		ResultSet rs = null; // tipo de resultado
		Connection con = null;
		PreparedStatement pst = null;
		try {
		   con = MySQLConexion.getConexion(); 
		   String sql = "select * from tb_usuarios"; // sentencia sql

		   pst = con.prepareStatement(sql);
		   // par�metros seg�n la sentencia		   
		   
		   rs = pst.executeQuery(); // tipo de ejecuci�n
		   
		   // Acciones adicionales en caso de consultas
		   while (rs.next()){
			   Usuario u = new Usuario();
			   u.setCodigo(rs.getInt(1));
			   u.setNombre(rs.getString(2));
			   lista.add(u);
		   }
		} catch (Exception e) {
		   System.out.println("Error en la sentencia " + e.getMessage());
		} finally {
		  try {
		      if (pst != null) pst.close();
		      if (con != null) con.close();
		   } catch (SQLException e) {
		      System.out.println("Error al cerrar ");
		   }
		}

		return lista;
	}

	

}
